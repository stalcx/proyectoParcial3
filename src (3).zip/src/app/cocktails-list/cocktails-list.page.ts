import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';  
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';  
@Component({
  selector: 'app-cocktails-list',
  templateUrl: './cocktails-list.page.html',
  styleUrls: ['./cocktails-list.page.scss'],
  standalone: true,
  imports: [IonicModule, HttpClientModule, CommonModule],  
})
export class CocktailsListPage {
  cocktails: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    
    this.http
      .get('https://www.thecocktaildb.com/api/json/v1/1/search.php?s=margarita')  
      .subscribe((response: any) => {
        
        
        
        if (response && response.drinks) {
          this.cocktails = response.drinks; 
        } else {
          
        }
      });
  }

 
  openDetail(id: string) {
    this.router.navigate([`/cocktail-detail/${id}`]);  
  }
}
