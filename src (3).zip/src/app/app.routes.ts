import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    redirectTo: 'home',  // Redirige a 'home' por defecto
  },
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.HomePage),
  },
  {
    path: 'cocktails-list',
    loadComponent: () => import('./cocktails-list/cocktails-list.page').then((m) => m.CocktailsListPage),
  },
  {
    path: 'cocktail-detail/:id',  
    loadComponent: () => import('./cocktail-detail/cocktail-detail.page').then((m) => m.CocktailDetailPage),
  },
];

