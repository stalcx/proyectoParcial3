import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-cocktail-detail',
  templateUrl: './cocktail-detail.page.html',
  styleUrls: ['./cocktail-detail.page.scss'],
  standalone: true,
  imports: [IonicModule],  
})
export class CocktailDetailPage {
  cocktail: any;
  ingredientsDetails: any[] = [];  

  constructor(private http: HttpClient, private route: ActivatedRoute) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');  
    console.log('ID del cóctel:', id);

    
    this.http
      .get(`https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${id}`)  
      .subscribe((response: any) => {
        this.cocktail = response.drinks ? response.drinks[0] : null;  
        console.log('Detalles del cóctel:', this.cocktail);  

        
        this.getIngredientDetails();
      });
  }

  
  getIngredientDetails() {
    const ingredientNames = this.getIngredients();  
    
    ingredientNames.forEach((ingredient) => {
      this.http
        .get(`https://www.thecocktaildb.com/api/json/v1/1/search.php?i=${ingredient}`)
        .subscribe((response: any) => {
          if (response.ingredients) {
            this.ingredientsDetails.push(response.ingredients[0]);  
          }
        });
    });
  }

 
  getIngredients() {
    const ingredients = [];
    for (let i = 1; i <= 15; i++) {
      const ingredient = this.cocktail[`strIngredient${i}`];
      if (ingredient) {
        ingredients.push(ingredient);
      }
    }
    return ingredients;
  }
}
