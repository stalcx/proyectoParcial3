import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-cocktail-detail',
  templateUrl: './cocktail-detail.page.html',
  styleUrls: ['./cocktail-detail.page.scss'],
  standalone: true,
  imports: [IonicModule],  // Asegúrate de incluir IonicModule
})
export class CocktailDetailPage {
  cocktail: any;
  ingredientsDetails: any[] = [];  // Para almacenar los detalles de los ingredientes

  constructor(private http: HttpClient, private route: ActivatedRoute) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');  // Obtener el ID desde la URL
    console.log('ID del cóctel:', id);

    // Realizar la solicitud para obtener los detalles del cóctel con el ID
    this.http
      .get(`https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${id}`)  // Llamada a la API con el ID
      .subscribe((response: any) => {
        this.cocktail = response.drinks ? response.drinks[0] : null;  // Asignar el cóctel recibido
        console.log('Detalles del cóctel:', this.cocktail);  // Verifica los detalles recibidos

        // Ahora obtenemos los detalles de los ingredientes usando la nueva API
        this.getIngredientDetails();
      });
  }

  // Método para obtener los detalles de los ingredientes
  getIngredientDetails() {
    const ingredientNames = this.getIngredients();  // Obtener los nombres de los ingredientes

    // Iterar sobre los ingredientes y hacer las solicitudes a la API para obtener detalles
    ingredientNames.forEach((ingredient) => {
      this.http
        .get(`https://www.thecocktaildb.com/api/json/v1/1/search.php?i=${ingredient}`)
        .subscribe((response: any) => {
          if (response.ingredients) {
            this.ingredientsDetails.push(response.ingredients[0]);  // Agregar los detalles del ingrediente
          }
        });
    });
  }

  // Método para obtener los ingredientes desde los campos 'strIngredient1', 'strIngredient2', etc.
  getIngredients() {
    const ingredients = [];
    for (let i = 1; i <= 15; i++) {
      const ingredient = this.cocktail[`strIngredient${i}`];
      if (ingredient) {
        ingredients.push(ingredient);
      }
    }
    return ingredients;
  }
}
