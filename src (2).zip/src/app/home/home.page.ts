import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';  // Importar IonicModule
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
  standalone: true,
  imports: [IonicModule],  // Asegúrate de incluir IonicModule para usar los componentes de Ionic
})
export class HomePage {
  constructor(private router: Router) {}

  // Función que navega a la página de cócteles
  goToCocktails() {
    this.router.navigate(['/cocktails-list']);  // Redirige a la página de cócteles
  }
}
