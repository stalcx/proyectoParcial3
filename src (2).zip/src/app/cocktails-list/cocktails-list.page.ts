import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';  // Importar HttpClient
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';  // Importar CommonModule para *ngFor

@Component({
  selector: 'app-cocktails-list',
  templateUrl: './cocktails-list.page.html',
  styleUrls: ['./cocktails-list.page.scss'],
  standalone: true,
  imports: [IonicModule, HttpClientModule, CommonModule],  // Incluir HttpClientModule, CommonModule
})
export class CocktailsListPage {
  cocktails: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  ngOnInit() {
    // Llamada a la API para obtener los cócteles
    this.http
      .get('https://www.thecocktaildb.com/api/json/v1/1/search.php?s=margarita')  // Buscando por el nombre "margarita"
      .subscribe((response: any) => {
        console.log('Respuesta completa de la API:', response);
        
        // Verifica si la respuesta contiene los cócteles
        if (response && response.drinks) {
          this.cocktails = response.drinks;  // Asigna los cócteles a la propiedad
        } else {
          console.log('No se encontraron cócteles');
        }
      });
  }

  // Navegar a la página de detalles de un cóctel
  openDetail(id: string) {
    this.router.navigate([`/cocktail-detail/${id}`]);  // Redirige a la página de detalles
  }
}
