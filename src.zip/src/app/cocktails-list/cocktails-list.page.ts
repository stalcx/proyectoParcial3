import { Component } from '@angular/core';
import { HttpClientModule, HttpClient } from '@angular/common/http';  // Importar HttpClientModule y HttpClient
import { Router } from '@angular/router';
import { IonicModule } from '@ionic/angular';  // Importar IonicModule
import { CommonModule } from '@angular/common';  // Importar CommonModule para *ngFor

@Component({
  selector: 'app-cocktails-list',
  templateUrl: './cocktails-list.page.html',
  styleUrls: ['./cocktails-list.page.scss'],
  standalone: true,
  imports: [IonicModule, HttpClientModule, CommonModule],  // Incluir IonicModule, HttpClientModule, CommonModule
})
export class CocktailsListPage {
  cocktails: any[] = [];

  constructor(private http: HttpClient, private router: Router) {}

  // Llamada a la API para obtener los cócteles
  ngOnInit() {
    this.http
      .get('https://www.thecocktaildb.com/api/json/v1/1/search.php?s=')  // URL de la API
      .subscribe((response: any) => {
        console.log(response);  // Verifica si la respuesta es correcta
        if (response.drinks) {
          this.cocktails = response.drinks;  // Asigna los cócteles a la propiedad 'cocktails'
        } else {
          console.log('No se encontraron cócteles');
        }
      });
  }

  // Función para navegar a la página de detalles del cóctel
  openDetail(id: string) {
    this.router.navigate([`/cocktail-detail/${id}`]);  // Redirige a la página de detalles del cóctel
  }
}
