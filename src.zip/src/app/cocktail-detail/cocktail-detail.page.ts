import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { IonicModule } from '@ionic/angular';

@Component({
  selector: 'app-cocktail-detail',
  templateUrl: './cocktail-detail.page.html',
  styleUrls: ['./cocktail-detail.page.scss'],
  standalone: true,
  imports: [IonicModule],  // Asegúrate de importar IonicModule
})
export class CocktailDetailPage {
  cocktail: any;

  constructor(private http: HttpClient, private route: ActivatedRoute) {}

  ngOnInit() {
    const id = this.route.snapshot.paramMap.get('id');
    this.http
      .get(`https://www.thecocktaildb.com/api/json/v1/1/lookup.php?i=${id}`)
      .subscribe((response: any) => {
        this.cocktail = response.drinks[0];
      });
  }
}

